import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../urls.dart'; // Ensure you have a urls.dart file with the base URL or IP defined

class Booking {
  final String id;
  final String parkingName;
  final String partnerEmail;
  final String userEmail;
  final String totalCost;
  final String floorNo;
  final String slotNo;
  final String start;
  final String end;
  final String status;
  final String profilePic;

  Booking({
    required this.id,
    required this.parkingName,
    required this.partnerEmail,
    required this.userEmail,
    required this.totalCost,
    required this.floorNo,
    required this.slotNo,
    required this.start,
    required this.end,
    required this.status,
    required this.profilePic,
  });

  factory Booking.fromJson(Map<String, dynamic> json) {
    return Booking(
      id: json['id'].toString(),
      parkingName: json['parkingname'].toString(),
      partnerEmail: json['partneremail'].toString(),
      userEmail: json['useremail'].toString(),
      totalCost: json['total_cost'].toString(),
      floorNo: json['floor_no'].toString(),
      slotNo: json['slot_no'].toString(),
      start: json['start'].toString(),
      end: json['end'].toString(),
      status: json['status'].toString(),
      profilePic: json['profilepic'] != null ? json['profilepic'].toString() : '',
    );
  }
}

class HistoryPage extends StatefulWidget {
  final String email;
  const HistoryPage({Key? key, required this.email}) : super(key: key);

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  late Future<List<Booking>> futureBookings;

  @override
  void initState() {
    super.initState();
    futureBookings = fetchBookings();
  }

  Future<List<Booking>> fetchBookings() async {
    final url = Uri.parse('${Urls.ip}/Parkeasy/partnerpendinghome.php');
    final response = await http.post(
      url,
      body: json.encode({'partneremail': widget.email}),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == 'success') {
        List<dynamic> data = jsonResponse['data'];
        List<Booking> bookings = data.map((json) => Booking.fromJson(json)).toList();

        // Sort bookings by start date in descending order
        bookings.sort((a, b) => DateTime.parse(b.start).compareTo(DateTime.parse(a.start)));

        return bookings;
      } else {
        throw Exception('Failed to load bookings');
      }
    } else {
      throw Exception('Failed to load bookings');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async {
          setState(() {
            futureBookings = fetchBookings();
          });
        },
        child: FutureBuilder<List<Booking>>(
          future: futureBookings,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return Center(child: Text('No bookings found'));
            } else {
              return ListView.builder(
                itemCount: snapshot.data!.length > 5 ? 5 : snapshot.data!.length,
                itemBuilder: (context, index) {
                  final booking = snapshot.data![index];
                  return Card(
                    margin: EdgeInsets.all(10),
                    elevation: 5,
                    child: Padding(
                      padding: EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                radius: 30,
                                backgroundImage: booking.profilePic.isNotEmpty
                                    ? MemoryImage(base64Decode(booking.profilePic))
                                    : null,
                                child: booking.profilePic.isEmpty
                                    ? Icon(Icons.person, size: 30)
                                    : null,
                              ),
                              SizedBox(width: 10),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    booking.userEmail,
                                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    'Parking Name: ${booking.parkingName}',
                                    style: TextStyle(fontSize: 15),
                                  ),
                                ],
                              ),
                              Spacer(),
                              Container(
                                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                                decoration: BoxDecoration(
                                  color: booking.status == 'approved'
                                      ? Colors.green
                                      : booking.status == 'rejected'
                                      ? Colors.red
                                      : Colors.orange,
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: Text(
                                  booking.status,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Text('Plot No: ${booking.slotNo}, Floor No: ${booking.floorNo}'),
                          Text('Start: ${booking.start}'),
                          Text('End: ${booking.end}'),
                          Text('Total Cost: \$${booking.totalCost}'),
                        ],
                      ),
                    ),
                  );
                },
              );
            }
          },
        ),
      ),
    );
  }
}
