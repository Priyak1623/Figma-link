import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../Colors.dart';
import '../urls.dart';

class RegisteredParkingStatus extends StatefulWidget {
  final String email;
  const RegisteredParkingStatus({Key? key, required this.email}) : super(key: key);

  @override
  State<RegisteredParkingStatus> createState() => _RegisteredParkingStatusState();
}

class _RegisteredParkingStatusState extends State<RegisteredParkingStatus> {
  List<Map<String, dynamic>> parkingData = [];

  @override
  void initState() {
    super.initState();
    fetchParkingStatus();
  }

  Future<void> fetchParkingStatus() async {
    final response = await http.post(
      Uri.parse('${Urls.ip}/Parkeasy/parkingstatusfetch.php'),
      body: jsonEncode({'email': widget.email}),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          parkingData = List<Map<String, dynamic>>.from(data['data']);
        });
      } else {
        print('Failed to fetch parking status: ${data['message']}');
      }
    } else {
      print('Error fetching parking status');
    }
  }

  void _showReasonDialog(String reason) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Rejection Reason'),
          content: Text(reason),
          actions: [
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Registered Parking Status', style: TextStyle(color: Colors.white)),
        backgroundColor: AppColors.backgroundColor,
      ),
      body: RefreshIndicator(
        onRefresh: fetchParkingStatus,
        child: ListView.builder(
          itemCount: parkingData.length,
          itemBuilder: (context, index) {
            final parking = parkingData[index];
            final imageBytes = base64Decode(parking['image']);
            final isRejected = parking['status'] == 'rejected';

            return Card(
              margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              elevation: 5,
              child: Container(
                decoration: BoxDecoration(
                  gradient: isRejected ? LinearGradient(
                    colors: [Colors.red[300]!, Colors.red[700]!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ) : LinearGradient(
                    colors: [Colors.green[300]!, Colors.green[700]!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Stack(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.memory(
                              imageBytes,
                              width: 100,
                              height: 100,
                              fit: BoxFit.cover,
                            ),
                          ),
                          SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  parking['name'],
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                  ),
                                ),
                                SizedBox(height: 8),
                                Text('Floors: ${parking['floors']}'),
                                Text('Cost: ${parking['cost']}'),
                                SizedBox(height: 8),
                                if (isRejected) ...[
                                  Row(
                                    children: [
                                      Icon(Icons.info, color: Colors.white),
                                      SizedBox(width: 8),
                                      Text(
                                        'Rejected',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    ],
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (isRejected) Positioned(
                      right: 8,
                      top: 8,
                      child: IconButton(
                        icon: Icon(Icons.info_outline, color: Colors.white),
                        onPressed: () => _showReasonDialog(parking['reason'] ?? 'No reason provided'),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
