import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:streetparking/urls.dart';
import 'package:http/http.dart'as http;

import '../Colors.dart';

class parnterparkingdetails extends StatefulWidget {
  final Map<String, dynamic> parking;
  final String email;
  const parnterparkingdetails({Key? key, required this.parking, required this.email}) : super(key: key);

  @override
  State<parnterparkingdetails> createState() => _parnterparkingdetailsState();
}

class _parnterparkingdetailsState extends State<parnterparkingdetails> {
  int selectedFloor = -1;
  int selectedSlot = -1;
  Map<int, Map<int, String>> slotStatuses = {};

  @override
  void initState() {
    super.initState();
    _fetchDisabledSlots();
  }

  Future<void> _fetchDisabledSlots() async {
    try {
      final response = await http.post(
        Uri.parse('${Urls.ip}/Parkeasy/bookedslots.php'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          'parkingname': widget.parking['name'],
          'partneremail': widget.parking['email']
        }),
      );

      if (response.statusCode == 200) {
        String responseBody = response.body;

        // Check for unexpected HTML tags and remove them if present
        if (responseBody.startsWith('<')) {
          // Assuming the HTML tag is at the beginning, remove everything until the first '{'
          final jsonStartIndex = responseBody.indexOf('{');
          if (jsonStartIndex != -1) {
            responseBody = responseBody.substring(jsonStartIndex);
          }
        }

        final responseData = json.decode(responseBody);
        if (responseData['status'] == 'success') {
          _processBookings(responseData['data']);
        } else {
          print('Failed to fetch booking data');
        }
      } else {
        print('Failed to send booking request: ${response.statusCode}');
        print('Response body: ${response.body}');
      }
    } catch (e) {
      print('Error during HTTP request: $e');
    }
  }

  void _processBookings(List<dynamic> bookings) {
    final now = DateTime.now();

    for (var booking in bookings) {
      final floorNo = booking['floor_no'];
      final slotNo = booking['slot_no'];
      final start = DateTime.parse(booking['start']);
      final end = DateTime.parse(booking['end']);
      final status = booking['status'];
      print(end);

      if (now.isAfter(start) && now.isBefore(end)) {
        if (!slotStatuses.containsKey(floorNo)) {
          slotStatuses[floorNo] = {};
        }
        slotStatuses[floorNo]![slotNo] = status;
      }
    }

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final imageBytes = base64Decode(widget.parking['image']);
    final int floors = int.parse(widget.parking['floors'].toString());
    final List<int> plots = (jsonDecode(widget.parking['plots'].toString()) as List<dynamic>)
        .map((e) => int.parse(e.toString()))
        .toList();

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.blue[100],
        title: Text(
          'Select the slot',
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              elevation: 5,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 200,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: MemoryImage(imageBytes),
                        fit: BoxFit.cover,
                      ),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(
                          child: Text(
                            widget.parking['name'],
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20),
                          ),
                        ),
                        SizedBox(height: 5),
                        Text('Cost: ${widget.parking['cost'].toString()} /hour'),
                        Text('Email: ${widget.parking['email']}'),
                        SizedBox(height: 10),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: floors,
                itemBuilder: (context, floorIndex) {
                  return Container(
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.blue.shade50, Colors.blue.shade100],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(
                          child: Text(
                            'Floor ${floorIndex + 1}',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20),
                          ),
                        ),
                        SizedBox(height: 10),
                        GridView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          gridDelegate:
                          SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 6,
                            childAspectRatio: 1,
                            mainAxisSpacing: 10,
                            crossAxisSpacing: 10,
                          ),
                          itemCount: plots[floorIndex],
                          itemBuilder: (context, plotIndex) {
                            final slotNo = plotIndex + 1;
                            final isSelected =
                                selectedFloor == floorIndex &&
                                    selectedSlot == slotNo;
                            final status = slotStatuses[floorIndex + 1]
                            ?[slotNo];
                            final isDisabled = status == 'accepted';

                            Color slotColor;
                            if (status == 'pending') {
                              slotColor = Colors.orange;
                            } else if (status == 'approved') {
                              slotColor = Colors.red;
                            } else {
                              slotColor = isSelected ? Colors.green : Colors.white;
                            }

                            return GestureDetector(
                              onTap: isDisabled
                                  ? null
                                  : () {
                                setState(() {
                                  selectedFloor = floorIndex;
                                  selectedSlot = slotNo;
                                });
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  color: slotColor,
                                  borderRadius: BorderRadius.circular(5),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 2,
                                      blurRadius: 5,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Text(
                                    '$slotNo',
                                    style: TextStyle(
                                      color: isDisabled
                                          ? Colors.white
                                          : isSelected
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            // ElevatedButton(
            //   onPressed: selectedSlot == -1
            //       ? null
            //       : () {
            //     final updatedParking =
            //     Map<String, dynamic>.from(widget.parking)
            //       ..['slot_no'] = selectedSlot
            //       ..['floor_no'] = selectedFloor + 1;
            //     Navigator.push(
            //       context,
            //       MaterialPageRoute(
            //         builder: (context) => Booking(
            //           parking: updatedParking,
            //           email: widget.email,
            //         ),
            //       ),
            //     );
            //   },
            //   style: ElevatedButton.styleFrom(
            //     foregroundColor: Colors.white,
            //     backgroundColor:
            //     selectedSlot == -1 ? Colors.grey : Colors.blueAccent,
            //     padding: EdgeInsets.symmetric(vertical: 15),
            //     shape: RoundedRectangleBorder(
            //       borderRadius: BorderRadius.circular(10),
            //     ),
            //   ),
            //   child: Text(
            //     'Book Now',
            //     style: TextStyle(fontSize: 18),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
