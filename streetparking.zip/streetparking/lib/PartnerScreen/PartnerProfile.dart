import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

import '../Colors.dart';
import '../urls.dart';

class PartnerProfile extends StatefulWidget {
  final String email;
  const PartnerProfile({Key? key, required this.email}) : super(key: key);

  @override
  State<PartnerProfile> createState() => _PartnerProfileState();
}

class _PartnerProfileState extends State<PartnerProfile> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController upiidController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();
  File? _image;
  String base64image = '';

  @override
  void initState() {
    super.initState();
    fetchUserDetails();
    emailController.text = widget.email;
  }

  Future<void> fetchUserDetails() async {
    final response = await http.post(
      Uri.parse('${Urls.ip}/Parkeasy/partnergeteditprofile.php'),
      body: jsonEncode({
        'email': widget.email,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        final userData = data['data'];
        setState(() {
          nameController.text = userData['name'];
          print(userData['profile_image']);
          upiidController.text = userData['upiid'];
          mobileController.text = userData['mobile'];
          base64image = userData['profile_image'];
        });
      } else {
        // Handle failure
        print('Failed to fetch user details: ${data['message']}');
      }
    } else {
      // Handle the error
      print('Error fetching user details');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        iconTheme: IconThemeData(
          color: Colors.white
        ),
        title: Text(' Profile',style: TextStyle(color: Colors.white),),
        backgroundColor:Colors.blue[100],
      ),

      body: RefreshIndicator(
        onRefresh: fetchUserDetails,
        child: Container(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                GestureDetector(
                  onTap: () {},
                  child: CircleAvatar(
                    radius: 60,
                    backgroundColor: Colors.white,
                    backgroundImage: base64image != null
                        ? MemoryImage(
                      base64Decode(base64image),
                    )
                        : null,
                    child: base64image == null ? Icon(Icons.add_a_photo) : null,
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  'Your Information',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 20),
                buildTextField(nameController, 'Name', readOnly: true),
                SizedBox(height: 20),
                buildTextField(emailController, 'Email', readOnly: true),
                SizedBox(height: 20),
                buildTextField(upiidController, 'UPI ID', readOnly: true),
                SizedBox(height: 20),
                buildTextField(
                  mobileController,
                  'Mobile',
                  keyboardType: TextInputType.number,
                  readOnly: true,
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildTextField(
      TextEditingController controller,
      String labelText, {
        bool readOnly = false,
        TextInputType keyboardType = TextInputType.text,
      }) {
    return TextField(
      controller: controller,
      readOnly: readOnly,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        labelText: labelText,
        labelStyle: TextStyle(color: Colors.black),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      style: TextStyle(color: Colors.black),
    );
  }

  /// Decode base64 image data to Uint8List
  Uint8List tryDecodeBase64Image(String base64Image) {
    try {
      return base64.decode(base64Image);
    } catch (e) {
      print('Error decoding base64 image: $e');
      return Uint8List(0);
    }
  }
}
