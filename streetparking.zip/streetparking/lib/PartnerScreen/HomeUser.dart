import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:streetparking/PartnerScreen/partnerparkingdetails.dart';
import 'package:streetparking/urls.dart';
import '../UserScreen/ParkingDetails.dart';

class HomeScreenUser extends StatefulWidget {
  final String email;

  const HomeScreenUser({Key? key, required this.email}) : super(key: key);

  @override
  State<HomeScreenUser> createState() => _HomeScreenUserState();
}

class _HomeScreenUserState extends State<HomeScreenUser> {
  List<Map<String, dynamic>> parkingData = [];

  @override
  void initState() {
    super.initState();
    fetchParkingStatus();
  }

  Future<void> fetchParkingStatus() async {
    final response = await http.post(
      Uri.parse('${Urls.ip}/Parkeasy/partnerviewhome.php'),
      body: jsonEncode({'email': widget.email}),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          parkingData = List<Map<String, dynamic>>.from(data['data']);
        });
      } else {
        print('Failed to fetch parking status: ${data['message']}');
      }
    } else {
      print('Error fetching parking status');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: RefreshIndicator(
        onRefresh: fetchParkingStatus,
        child: ListView.builder(
          padding: EdgeInsets.all(10),
          itemCount: parkingData.length,
          itemBuilder: (context, index) {
            final parking = parkingData[index];
            final imageBytes = base64Decode(parking['image'] ?? '');

            if (parking['status'] != 'approved') {
              return SizedBox.shrink();
            }

            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => parnterparkingdetails(
                      parking: parking,
                      email: widget.email,
                    ),
                  ),
                );
              },
              child: Container(

                margin: const EdgeInsets.symmetric(vertical: 10),
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (parking['image'] != null)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.memory(
                          imageBytes,
                          height: 200,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),
                    SizedBox(height: 10),
                    Text(
                      parking['name'],
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 22,
                        color: Colors.black87,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Cost: ${parking['cost']} Per hour',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black54,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Floors: ${parking['floors']}',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black54,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Email: ${parking['email']}',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black54,
                      ),
                    ),
                    SizedBox(height: 5),
                    // Text(
                    //   'Plots: ${parking['plots']}',
                    //   style: TextStyle(
                    //     fontSize: 16,
                    //     color: Colors.black54,
                    //   ),
                    // ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
