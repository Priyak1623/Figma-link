import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../urls.dart';
import 'ParkingDetails.dart';

class userhomescreen extends StatefulWidget {
  final String email;
  const userhomescreen({Key? key, required this.email}) : super(key: key);

  @override
  State<userhomescreen> createState() => _userhomescreenState();
}

class _userhomescreenState extends State<userhomescreen> {
  List<Map<String, dynamic>> parkingData = [];

  @override
  void initState() {
    super.initState();
    fetchParkingStatus();
  }

  Future<void> fetchParkingStatus() async {
    final response = await http.post(
      Uri.parse('${Urls.ip}/Parkeasy/adminstatuspage.php'),
      body: jsonEncode({}),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          parkingData = List<Map<String, dynamic>>.from(data['data']);
        });
      } else {
        print('Failed to fetch parking status: ${data['message']}');
      }
    } else {
      print('Error fetching parking status');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: fetchParkingStatus,
        child: ListView.builder(
          itemCount: parkingData.length,
          itemBuilder: (context, index) {
            final parking = parkingData[index];
            final imageBytes = base64Decode(parking['image']);

            // Show list item only if the status is approved
            if (parking['status'] != 'approved') {
              return SizedBox.shrink();
            }

            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ParkingDetailsPage(parking: parking, email: widget.email,),
                  ),
                );
              },
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: Offset(0, -1),
                  end: Offset.zero,
                ).animate(CurvedAnimation(
                  parent: ModalRoute.of(context)!.animation!,
                  curve: Curves.easeInOut,
                )),
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Container(
                        height: 200,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: MemoryImage(imageBytes),
                            fit: BoxFit.cover,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      SizedBox(height: 10),
                      Text(
                        parking['name'],
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                      ),
                      SizedBox(height: 5),
                      Text('Cost: ${parking['cost']}/ hour'),
                      Text('Floors: ${parking['floors']}'),
                      Text('Email: ${parking['email']}'),
                      //Text('Plots: ${parking['plots']}'),
                      SizedBox(height: 10),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}