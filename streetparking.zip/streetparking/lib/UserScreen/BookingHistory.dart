import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../Colors.dart';
import '../urls.dart';
class Payment {
  final String parkingName;
  final String totalCost;
  final String paymentStatus;
  final String transactionId;
  final String floor_no;
  final String slot_no;
  final String Start;
  final String end;

  Payment({
    required this.parkingName,
    required this.totalCost,
    required this.paymentStatus,
    required this.transactionId,
    required this.floor_no,
    required this.slot_no,
    required this.Start,
    required this.end,
  });

  factory Payment.fromJson(Map<String, dynamic> json) {
    return Payment(
      parkingName: json['parkingname'].toString(),
      totalCost: json['total_cost'].toString(),
      paymentStatus: json['payment_status'].toString(),
      transactionId: json['transactionid'].toString(),
      floor_no: json['floor_no'].toString(),
      slot_no: json['slot_no'].toString(),
      Start: json['start'].toString(),
      end: json['end'].toString(),

    );
  }
}
class BookingHistory extends StatefulWidget {
  final String email;
  const BookingHistory({Key? key, required this.email}) : super(key: key);

  @override
  State<BookingHistory> createState() => _BookingHistoryState();
}

class _BookingHistoryState extends State<BookingHistory> {
  late Future<List<Payment>> futurePayments;

  @override
  void initState() {
    super.initState();
    futurePayments = fetchPayments();
  }

  Future<List<Payment>> fetchPayments() async {
    final url = Uri.parse('${Urls.ip}/Parkeasy/payment_history.php');
    final response = await http.post(
      url,
      body: json.encode({'email': widget.email}),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == 'success') {
        List<dynamic> data = jsonResponse['data'];
        return data.map((json) => Payment.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load payments');
      }
    } else {
      throw Exception('Failed to load payments');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Booking History'),
        centerTitle: true,
        foregroundColor: Colors.white,
        backgroundColor: AppColors.backgroundColor,
      ),
      body: FutureBuilder<List<Payment>>(
        future: futurePayments,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No payments found'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final payment = snapshot.data![index];
                final firstLetter = payment.parkingName.isNotEmpty
                    ? payment.parkingName[0].toUpperCase()
                    : '';

                return Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                  elevation: 5,
                  child: ListTile(
                    contentPadding: EdgeInsets.all(15),
                    leading: CircleAvatar(
                      backgroundColor: Colors.blueAccent,
                      radius: 30,
                      child: Text(
                        firstLetter,
                        style: TextStyle(
                          fontSize: 26,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    title: Text(
                      payment.parkingName,
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 5),
                        Text('Floor No: ${payment.floor_no} ',
                            style: TextStyle(fontSize: 16)),
                        Text('Slot_No: ${payment.slot_no}',
                            style: TextStyle(fontSize: 16)),
                        Text('Start Date: ${payment.Start}',
                            style: TextStyle(fontSize: 12)),
                        Text('End Date: ${payment.end}',
                            style: TextStyle(fontSize: 12)),
                      ],
                    ),
                    trailing: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        backgroundColor: payment.paymentStatus == 'Pending'
                            ? Colors.orange
                            : payment.paymentStatus == 'failed'
                            ? Colors.red
                            : Colors.green,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      child: Text(
                        payment.paymentStatus,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),

                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
