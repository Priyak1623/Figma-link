import 'package:flutter/material.dart';
import 'package:streetparking/Colors.dart';
import 'package:streetparking/LoginPages/UserLogin.dart';
import 'Colors.dart';
import 'LoginPages/PartenerLogin.dart';

import 'LoginPages/adminLogin.dart';
import 'urls.dart'; // Make sure to import the URLs class

class LoginOptions extends StatefulWidget {
  const LoginOptions({Key? key}) : super(key: key);

  @override
  _LoginOptionsState createState() => _LoginOptionsState();
}

class _LoginOptionsState extends State<LoginOptions> {
  final TextEditingController _ipController = TextEditingController();

  void _navigateToLogin(BuildContext context, String role) {
    final ipAddress = _ipController.text.trim();
    if (ipAddress.isNotEmpty) {
      Urls.ip = "http://$ipAddress"; // Update URL
      Widget targetPage;
      switch (role) {
        case 'Admin':
          targetPage = AdminLogin();
          break;
        case 'Partner':
          targetPage = PartnerLogin();
          break;
        case 'User':
          targetPage = UserLogin();
          break;
        default:
          targetPage = UserLogin(); // Default to UserLogin if role is unknown
      }
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => targetPage,
        ),
      );
    } else {
      _showError("Please enter a valid IP address.");
    }
  }

  void _showError(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Error"),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: AppColors.backgroundColor,
        child: Column(
          children: [
            SizedBox(height: 80.0),
            Center(
              child: Image.asset(
                'assets/toplogin.png',
                width: 300.0,
                height: 300.0,
              ),
            ),
            SizedBox(height: 20.0),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: TextField(
                controller: _ipController,
                decoration: InputDecoration(
                  labelText: "Enter IP Address",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  fillColor: Colors.white,
                  filled: true,
                ),

              ),
            ),
            SizedBox(height: 20.0),
            Expanded(
              child: ListView(
                children: [
                  _buildLoginOption(
                    context,
                    'Admin',
                    Colors.blueAccent,
                    'assets/adminicon.png',
                  ),
                  _buildLoginOption(
                    context,
                    'Partner',
                    Colors.blueAccent,
                    'assets/partner.png',
                  ),
                  _buildLoginOption(
                    context,
                    'User',
                    Colors.blueAccent,
                    'assets/userep.png',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoginOption(
      BuildContext context,
      String title,
      Color iconBackgroundColor,
      String imagePath,
      ) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
      child: Stack(
        children: [
          Container(
            margin: EdgeInsets.only(left: 60.0),
            child: Card(
              child: ListTile(
                onTap: () => _navigateToLogin(context, title),
                title: Text(
                  title,
                  style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 2.0,
            left: 0,
            bottom: 1,
            child: Align(
              alignment: Alignment.centerLeft,
              child: Container(
                width: 70.0,
                height: 70.0,
                decoration: BoxDecoration(
                  color: iconBackgroundColor,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Image.asset(
                    imagePath,
                    width: 30.0,
                    height: 30.0,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
