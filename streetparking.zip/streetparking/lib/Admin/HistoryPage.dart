import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../urls.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({Key? key}) : super(key: key);

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  List<Map<String, dynamic>> parkingData = [];

  @override
  void initState() {
    super.initState();
    fetchParkingStatus();
  }

  Future<void> fetchParkingStatus() async {
    final response = await http.post(
      Uri.parse('${Urls.ip}/Parkeasy/adminstatuspage.php'),
      body: jsonEncode({}),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          parkingData = List<Map<String, dynamic>>.from(data['data']);
        });
      } else {
        print('Failed to fetch parking status: ${data['message']}');
      }
    } else {
      print('Error fetching parking status');
    }
  }

  Future<void> changeParkingStatus(String action, String name, String email) async {
    final response = await http.post(
      Uri.parse('${Urls.ip}/Parkeasy/adminstatuschanging.php'),
      body: jsonEncode({
        'action': action,
        'name': name,
        'email': email,
      }),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      print('Response: $data');
    } else {
      print('Error changing parking status');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: fetchParkingStatus,
        child: ListView.builder(
          itemCount: parkingData.length,
          itemBuilder: (context, index) {
            final parking = parkingData[index];
            final imageBytes = base64Decode(parking['image']);

            // Determine container color and button color based on parking status
            Color containerColor = parking['status'] == 'approved' ? Colors.white : Colors.white;
            Color buttonColor = parking['status'] == 'approved' ? Colors.green : Colors.red;
            IconData buttonIcon = parking['status'] == 'approved' ? Icons.check : Icons.close;

            // Show list item only if the status is pending
            if (parking['status'] == 'pending') {
              return SizedBox.shrink(); // Return empty widget
            }

            return SlideTransition(
              position: Tween<Offset>(
                begin: Offset(0, -1),
                end: Offset.zero,
              ).animate(CurvedAnimation(
                parent: ModalRoute.of(context)!.animation!,
                curve: Curves.easeInOut,
              )),
              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 10),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: containerColor,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      height: 200,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: MemoryImage(imageBytes),
                          fit: BoxFit.cover,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      parking['name'],
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                    ),
                    SizedBox(height: 5),
                    Text('Cost: ${parking['cost']}'),
                    Text('Floors: ${parking['floors']}'),
                    SizedBox(height: 10),
                    Text('Status: ${parking['status']}'),
                    SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        ElevatedButton.icon(
                          onPressed: () {
                            final name = parking['name'];
                            final email = parking['email'];
                            final action = parking['status'] == 'approved' ? 'reject' : 'accept';
                            changeParkingStatus(action, name, email);
                          },
                          icon: Icon(buttonIcon),
                          label: Text(parking['status'], style: TextStyle(color: Colors.white)),
                          style: ElevatedButton.styleFrom(
                            primary: buttonColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
