import 'package:flutter/material.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:url_launcher/url_launcher.dart';

class Contactuspage extends StatelessWidget {
  const Contactuspage({Key? key}) : super(key: key);

  void _callNumber(String number) async {
    bool? res = await FlutterPhoneDirectCaller.callNumber(number);
    if (res!) {
      // Handle the error if the call failed to launch
      print('Failed to make a call');
    }
  }

  void _sendEmail() async {
    final url = 'mailto:dude@gmail.com';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,

        title: Text(
          'Support Page',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.blue[200],
        iconTheme: IconThemeData(color: Colors.white),
      ),
       // Light lavender color
      body: Column(
        children: [
          SizedBox(height: 80), // Space from top
          Container(
            padding: EdgeInsets.symmetric(horizontal: 70, vertical: 20),
            decoration: BoxDecoration(
              color: Colors.blue[200],
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              'Contact Us',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white
              ),
            ),
          ),
          Expanded(
            child: Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  InkWell(
                    onTap: () {
                      _callNumber("+918008017003");
                    },
                    child: ContactOption(
                      icon: Icons.phone,
                      label: 'Phone',
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      _sendEmail;
                    },
                    child: ContactOption(
                      icon: Icons.email,
                      label: 'Email',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ContactOption extends StatelessWidget {
  final IconData icon;
  final String label;

  const ContactOption({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 150,
      height: 150,
      decoration: BoxDecoration(
        color: Colors.blue[200],
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 50,
            color: Colors.white,
          ),
          SizedBox(height: 10),
          Text(
            label,
            style: TextStyle(
              fontSize: 20,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
