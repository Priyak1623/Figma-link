<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"]) && isset($data["name"]) && isset($data["upiid"]) && isset($data["mobile"])&&isset($data["profile_image"])) {
        $email = $data["email"];
        $name = $data["name"];
        $upiid = $data["upiid"];
        $mobile = $data["mobile"];
        $profile_image = $data["profile_image"];

        // Establish the database connection
        $servername = "localhost";
        $username_db = "root";
        $password_db = "";
        $dbname = "parkeasy";

        $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if ($profile_image != '') {
            $image_name = $email . ".png";
            $image_path = "profilepic/" . $image_name;
            file_put_contents($image_path, base64_decode($profile_image));
        }

        $sql = "UPDATE user SET name='$name', upiid='$upiid', mobile='$mobile' WHERE email='$email'";
        if ($conn->query($sql) === TRUE) {
            $response['status'] = 'success';
            $response['message'] = 'Profile updated successfully';
        } else {
            $response['status'] = 'failure';
            $response['message'] = 'Error updating profile: ' . $conn->error;
        }

        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Invalid input data';
    }

    echo json_encode($response);
}
