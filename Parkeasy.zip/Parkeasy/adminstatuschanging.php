<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["action"]) && isset($data["email"]) && isset($data["name"])) {
        $action = $data["action"];
        $email = $data["email"];
        $name = $data["name"];
        $reason = isset($data["reason"]) ? $data["reason"] : null;

        // Establish the database connection
        $servername = "localhost";
        $username_db = "root";
        $password_db = "";
        $dbname = "parkeasy";
        
        $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Retrieve parking data from the database based on email and name
        $sql = "SELECT name, email, status FROM parking WHERE email = '$email' AND name = '$name'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Update status based on action
            if ($action === "approve") {
                $status = "approved";
                $reason = null; // Set reason to null for approve action
            } elseif ($action === "reject") {
                $status = "rejected";
                // Reason should already be set from the input data
            } else {
                $response['status'] = 'failure';
                $response['message'] = 'Invalid action';
                echo json_encode($response);
                exit;
            }

            // Update status and reason in the database
            if ($reason !== null) {
                $update_sql = "UPDATE parking SET status = '$status', reason = '$reason' WHERE email = '$email' AND name = '$name'";
            } else {
                $update_sql = "UPDATE parking SET status = '$status', reason = NULL WHERE email = '$email' AND name = '$name'";
            }
            if ($conn->query($update_sql) === TRUE) {
                $response['status'] = 'success';
                $response['message'] = 'Status updated successfully';
            } else {
                $response['status'] = 'failure';
                $response['message'] = 'Error updating status: ' . $conn->error;
            }
        } else {
            $response['status'] = 'failure';
            $response['message'] = 'No record found for the provided email and name';
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Invalid input data';
    }

    echo json_encode($response);
}
