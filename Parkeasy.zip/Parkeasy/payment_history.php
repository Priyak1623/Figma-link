<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {


    $json = file_get_contents('php://input');
    $data = json_decode($json, true);


    $email = $data['email'];

   
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "parkeasy";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

 
    $sql = "SELECT parkingname, total_cost,slot_no,floor_no,start,end, 
                   COALESCE(payment_status, 'Pending') AS payment_status, 
                   transactionid 
            FROM booking 
            WHERE useremail = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    $payments = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $payments[] = $row;
        }
    }


    $stmt->close();
    $conn->close();

    // Send JSON response
    header('Content-Type: application/json');
    echo json_encode(array("status" => "success", "data" => $payments));
} else {
    // Invalid request method
    header("HTTP/1.1 405 Method Not Allowed");
    echo json_encode(array("status" => "failure", "message" => "Method Not Allowed"));
}

