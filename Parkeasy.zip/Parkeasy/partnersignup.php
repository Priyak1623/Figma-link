<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"]) && isset($data["password"]) && isset($data["mobile"]) && isset($data["gender"])&&isset($data["name"])) {
        $email = $data["email"];
        $password = $data["password"];
        $mobile = $data["mobile"];
        $gender = $data["gender"];
        $name = $data["name"];

        // Establish the database connection
        $servername = "localhost";
        $username_db = "root";
        $password_db = "";
        $dbname = "parkeasy";
        
        $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Check for duplicate email
        $sql = "SELECT * FROM partner WHERE email = '$email'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $response['status'] = 'failure';
            $response['message'] = 'Email already exists';
            echo json_encode($response);
            $conn->close();
            exit();
        }

        // Check for duplicate mobile number
        $sql = "SELECT * FROM partner WHERE mobile = '$mobile'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $response['status'] = 'failure';
            $response['message'] = 'Mobile number already exists';
            echo json_encode($response);
            $conn->close();
            exit();
        }

        // Insert user data into the database
        $sql = "INSERT INTO partner (email, password, mobile, gender,name) VALUES ('$email', '$password', '$mobile', '$gender','$name')";
        if ($conn->query($sql) === TRUE) {
            $response['status'] = 'success';
            $response['message'] = 'User registered successfully';
        } else {
            $response['status'] = 'failure';
            $response['message'] = 'Error: ' . $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Invalid input data';
    }

    echo json_encode($response);
}

