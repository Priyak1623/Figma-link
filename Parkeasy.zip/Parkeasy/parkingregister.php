<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"]) &&isset($data["name"]) && isset($data["cost"]) && isset($data["floors"]) && isset($data["plots"])&& isset($data["image"])) {
        $email = $data["email"];
        $name = $data["name"];
        $cost = $data["cost"];
        $floors = $data["floors"];
        $plots = $data["plots"];
        $base64Image = $data['image'];

        // Convert plots array to JSON
        $plots_json = json_encode($plots);

        // Establish the database connection
        $servername = "localhost";
        $username_db = "root";
        $password_db = "";
        $dbname = "parkeasy";
        
        $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Insert parking data into the database
        $sql = "INSERT INTO parking (email,name, cost, floors, plots,status) VALUES ('$email','$name', '$cost', '$floors', '$plots_json','pending')";
        if ($conn->query($sql) === TRUE) {


            $imageData = base64_decode($base64Image);
            $imageName = $name. '.png'; // Generate a unique image name
            $filePath = 'parkingimage/' . $imageName;
            file_put_contents($filePath, $imageData);


            $response['status'] = 'success';
            $response['message'] = 'Parking data inserted successfully';
        } else {
            $response['status'] = 'failure';
            $response['message'] = 'Error: ' . $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Invalid input data';
    }

    echo json_encode($response);
}
?>