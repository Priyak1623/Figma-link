<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data from the request body
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Extract data from JSON
    $parkingname = $data['parkingname'];
    $partneremail = $data['partneremail'];
    $useremail = $data['useremail'];
    $total_cost = $data['total_cost'];
    $floor_no = $data['floor_no'];
    $slot_no = $data['slot_no'];
    $start = $data['start'];
    $end = $data['end'];
    $status = 'pending'; // Set default status to 'pending'
    $payment_status = $data['payment_status'] ?? 'pending';
    $transaction_id = $data['transaction_id'] ?? null;

    // Establish database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "parkeasy";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind SQL statement
    $sql = "INSERT INTO booking (parkingname, partneremail, useremail, total_cost, floor_no, slot_no, start, end, status, payment_status, transactionid) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?)";

    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("sssisssssss", $parkingname, $partneremail, $useremail, $total_cost, $floor_no, $slot_no, $start, $end, $status, $payment_status, $transaction_id);
    if ($stmt->execute()) {
        $response['status'] = 'success';
        $response['message'] = 'Booking inserted successfully';
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Error inserting booking: ' . $conn->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    // Send JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    // Invalid request method
    header("HTTP/1.1 405 Method Not Allowed");
    echo json_encode(array("status" => "failure", "message" => "Method Not Allowed"));
}
?>
