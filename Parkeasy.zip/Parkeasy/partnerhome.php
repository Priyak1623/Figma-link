<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data from the request body
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Extract parameters
    $bookingId = $data['booking_id'];
    $newStatus = $data['new_status'];

    // Establish database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "parkeasy";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute SQL statement to update booking status
    $sql = "UPDATE booking SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $newStatus, $bookingId);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        // Status updated successfully
        $stmt->close();
        $conn->close();
        echo json_encode(array("status" => "success"));
    } else {
        // Failed to update status
        $stmt->close();
        $conn->close();
        echo json_encode(array("status" => "failure", "message" => "Failed to update status"));
    }

} else {
    // Invalid request method
    header("HTTP/1.1 405 Method Not Allowed");
    echo json_encode(array("status" => "failure", "message" => "Method Not Allowed"));
}

?>
