<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Decode JSON data from the request body
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Extract the email from JSON
    $email = $data['email'];

    // Establish database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "parkeasy";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute SQL statement to fetch bookings based on useremail
    $sql = "SELECT id, parkingname, partneremail, useremail, total_cost, floor_no, slot_no, start, end, status FROM booking WHERE useremail = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    $bookings = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Get the profile picture file path based on useremail
            $profilePicPath = "parkingimage/" . $row['parkingname'] . ".png"; // Adjust the file path and extension as needed

            // Check if the profile picture file exists and read it
            if (file_exists($profilePicPath)) {
                $profilePicData = file_get_contents($profilePicPath);
                $row['profilepic'] = base64_encode($profilePicData);
            } else {
                $row['profilepic'] = null; // Or handle as needed if profile pic is not found
            }

            $bookings[] = $row;
        }
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    // Send JSON response
    header('Content-Type: application/json');
    echo json_encode(array("status" => "success", "data" => $bookings));
} else {
    // Invalid request method
    header("HTTP/1.1 405 Method Not Allowed");
    echo json_encode(array("status" => "failure", "message" => "Method Not Allowed"));
}

